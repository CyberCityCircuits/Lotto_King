Lotto King 0.01.00
David Ray
David@DREAM-Enterprise.com

Lotto King is a simple application that allows for the entry of lottery tickets into a spreadsheet quickly and efficently.  Just add the tickets in the order that you want to count them to the file named 'list_tickets.txt' followed by a ',' and the cost of that ticket.

Example:
$5 Jumbo, 5
Money For Life, 20
Magic Money, 10

The prompts will show up in the order you have the added to the list.  

This version is early in development so it can not account for adding new rolls of tickets.  If you add a new roll you will need to add the ending count to the count of the last roll.  For example, if a roll has 300 tickets and you started at 290 and you add a new roll and end at 120, you will add 300 to the 120 to get an accurate count with the software.

Please send any questions and concerns to David@DREAM-Enterprise.com

Thank you.